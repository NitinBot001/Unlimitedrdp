const API_URL = "https://api.github.com/repos/NitinBot001/Sunno/commits";
const lastCommitKey = "77448e37dc5940c75795114c0b1ea31e6ace8126"; // LocalStorage key to save the last commit SHA
let updateButton = null;

// Function to fetch and display commits
function fetchAndDisplayCommits() {
  fetch(API_URL)
    .then(response => response.json())
    .then(commits => {
      if (Array.isArray(commits) && commits.length > 0) {
        handleCommits(commits);
      } else {
        throw new Error("No commits found");
      }
    })
    .catch(error => {
      console.error("Error fetching commit data:", error);
      document.getElementById("version-recent-commits").innerHTML = "<li>Error loading commits</li>";
    });
}

// Handle commit data
function handleCommits(commits) {
  const recentCommits = document.getElementById("version-recent-commits");
  const lastCommitSHA = localStorage.getItem(lastCommitKey);
  const latestCommit = commits[0];

  // Update the UI with the latest commit information
  document.getElementById("version-last-update").textContent = formatDate(latestCommit.commit.author.date);
  document.getElementById("version-app-version").textContent = `Latest Commit: ${latestCommit.sha.substring(0, 7)}`;

  // Clear previous commits and display the latest ones
  recentCommits.innerHTML = "";
  commits.slice(0, 5).forEach(commit => {
    const listItem = document.createElement("li");
    listItem.innerHTML = `
      <strong>Message:</strong> ${commit.commit.message} <br>
      <strong>Author:</strong> ${commit.commit.author.name} <br>
      <strong>Date:</strong> ${formatDate(commit.commit.author.date)} <br>
      <a href="${commit.html_url}" target="_blank">View Commit</a>
    `;
    recentCommits.appendChild(listItem);
  });

  // Check if there is a new commit
  if (latestCommit.sha !== lastCommitSHA) {
    enableUpdateButton(latestCommit.sha);
  } else {
    disableUpdateButton();
  }
}

// Enable the update button and save the new commit SHA
function enableUpdateButton(latestCommitSHA) {
  updateButton.style.display = "block";
  updateButton.onclick = () => {
    alert("Updating the app...");
    localStorage.setItem(lastCommitKey, latestCommitSHA);
    disableUpdateButton();
    // Here, add your logic to trigger an app update, like restarting the activity or fetching new resources.
  };
}

// Disable the update button
function disableUpdateButton() {
  updateButton.style.display = "none";
  updateButton.onclick = null;
}

// Format date to a readable string
function formatDate(dateString) {
  const date = new Date(dateString);
  return date.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}

// Initialize the app
function initApp() {
  updateButton = document.getElementById("version-update-button");
  fetchAndDisplayCommits();
}

// Track updates whenever the app activity starts
window.addEventListener("load", initApp);